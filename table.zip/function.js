function canadaCategory(){
    $('#category0').removeClass('d-none');
    $('#category1').removeClass('d-none');
    $('#category2').removeClass('d-none');
    $('#category3').removeClass('d-none');
    $('#category4').addClass('d-none');
    $('#category5').removeClass('d-none');
    $('#category6').removeClass('d-none');
    $('#category7').removeClass('d-none');
    $('#category8').removeClass('d-none');
    $('#category9').removeClass('d-none');
    $('#category10').removeClass('d-none');
    $('#category11').removeClass('d-none');
    $('#category12').removeClass('d-none');
}
function franceCategory(){
    $('#category4').removeClass('d-none');
    $('#category0').addClass('d-none');
    $('#category1').addClass('d-none');
    $('#category2').addClass('d-none');
    $('#category3').addClass('d-none');
    $('#category5').addClass('d-none');
    $('#category6').addClass('d-none');
    $('#category7').addClass('d-none');
    $('#category8').addClass('d-none');
    $('#category9').addClass('d-none');
    $('#category10').addClass('d-none');
    $('#category11').addClass('d-none');
    $('#category12').addClass('d-none');
}

function allTable(){
    $('#table0').addClass('d-none');
    $('#table01').addClass('d-none');
    $('#table02').addClass('d-none');
    $('#table03').addClass('d-none');
}


